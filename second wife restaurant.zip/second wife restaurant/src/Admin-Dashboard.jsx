import React from 'react';

const AdminDashboard = () => {
  return (
    <section>
      <h2>Admin Dashboard</h2>
      {/* Implement admin dashboard functionality */}
    </section>
  );
}

export default AdminDashboard;
